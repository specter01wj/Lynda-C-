﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class Program
    {

        const int Value1 = 12;
        const int Value2 = 24;

        static void Main(string[] args)
        {

        }
    }
}
